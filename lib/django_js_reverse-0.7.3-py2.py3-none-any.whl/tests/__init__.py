# -*- coding: utf-8 -*-
from tests.unit_tests import JSReverseViewTestCaseMinified, JSReverseViewTestCaseNotMinified, \
    JSReverseViewTestCaseGlobalObjectName, JSReverseStaticFileSaveTest, JSReverseTemplateTagTest
